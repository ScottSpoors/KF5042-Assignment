emb = fastTextWordEmbedding;

data = readLexicon;

idx = ~isVocabularyWord(emb,data.Word);
data(idx,:) = [];

numWords = size(data,1);
cvp = cvpartition(numWords,'HoldOut',0.1);
dataTrain = data(training(cvp),:);
dataTest = data(test(cvp),:);

wordsTrain = dataTrain.Word;
XTrain = word2vec(emb,wordsTrain);
YTrain = dataTrain.Label;

mdl = fitcsvm(XTrain,YTrain);

wordsTest = dataTest.Word;
XTest = word2vec(emb,wordsTest);
YTest = dataTest.Label;

[YPred,scores] = predict(mdl,XTest);

figure
confusionchart(YTest,YPred);

filename = "labeled_data.csv";
tbl = readtable(filename,'TextType','string');
textData = tbl.tweet;
textData(1:10);

documents = preprocessText(textData);
idx = ~isVocabularyWord(emb,documents.Vocabulary);
documents = removeWords(documents,idx);

words = documents.Vocabulary;
words(ismember(words,wordsTrain)) = [];

vec = word2vec(emb,words);
[YPred,scores] = predict(mdl,vec);

for i = 1:numel(documents)
   words = string(documents(i));
   vec = word2vec(emb,words);
   [~,scores] = predict(mdl,vec);
   sentimentScore(i) = mean(scores(:,1));
end

table(sentimentScore',textData)

function data = readLexicon
    fidHateSpeech = fopen(fullfile('Dataset','hate-speech-and-offensive-language-master','lexicons','refined_ngram_dict.csv'));
    C = textscan(fidHateSpeech,'%s','CommentStyle',';');
    HateSpeech = string(C{1});
    
    fclose all;
    
    words = [HateSpeech];
    labels = categorical(nan(numel(words),1));
    labels(1:numel(HateSpeech)) = "HateSpeech";
    
    data = table(words,labels,'VariableNames',{'Word','Label'});
end

function documents = preprocessText(textData)
    documents = tokenizedDocument(textData);
    documents = erasePunctuation(documents);
    documents = removeStopWords(documents);
    documents = lower(documents);
end
